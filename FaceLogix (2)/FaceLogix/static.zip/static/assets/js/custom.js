// Example custom JavaScript code in custom.js

// Function to add any additional custom behavior if needed
document.addEventListener("DOMContentLoaded", function () {
    const adminLoginButton = document.querySelector('.btn.btn-primary');
    if (adminLoginButton) {
        // You can add other event listeners or functionality here if needed
    }
});

// Additional custom functions can go here
